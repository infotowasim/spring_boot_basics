package io.javabrains.springbootstarter.topic;

import org.springframework.data.repository.CrudRepository;

public interface TopicRepository extends CrudRepository<Topic,String> {
	

	//Crud operation
	//getAllTopics()
	//getTopic(String id)
	//updateTopic(Topic t)
	//daleteTopic(String id)
	
	
	
	
	

}
